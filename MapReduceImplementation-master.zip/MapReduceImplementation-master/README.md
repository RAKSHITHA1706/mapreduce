# MapReduceImplementation
 
 StudentsData MapReduce program to find total number of students scored >60 in subject 1 & number of students passed in all subjects.
 
 1.Creating a dataset in excel as .csv file 
 2. Creating .java file with Mapper,Reducer and Driver Code
 3.Building Path and Exporting JAR file
 4.Creating Input file in HadoopFileSystem and storing the output to Output File 
